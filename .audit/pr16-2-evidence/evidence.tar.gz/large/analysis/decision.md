# Echo host matrix decision

| Mode | Median outer ms | p95 outer ms |
| --- | ---: | ---: |
| CPU | 19270.165 | 20223.41 |
| Accelerated | 6063.639 | 6766.843 |

Median reduction: **13137.036 ms (68.063%)**.

| Language | CPU WER | Accelerated WER | Delta pp | Quality gate |
| --- | ---: | ---: | ---: | --- |
| de | 3.23% | 3.23% | 0.0 | PASS |
| en | 31.30% | 30.89% | -0.407 | PASS |
| es | 0.85% | 0.85% | 0.0 | PASS |
| fr | 5.93% | 5.93% | 0.0 | PASS |
| nl | 2.70% | 2.70% | 0.0 | PASS |

## Gates

- PASS: `completePairs`
- PASS: `pairIntegrity`
- PASS: `sampleSize`
- PASS: `backendTruth`
- PASS: `identityMatch`
- PASS: `hardwareDevice`
- FAIL: `driverIcdIdentity`
- FAIL: `freshAndPopulatedCacheEvidence`
- FAIL: `resetEvidence`
- PASS: `medianReduction`
- PASS: `medianSpeedup`
- PASS: `p95Improved`
- PASS: `perLanguageQuality`
- PASS: `noNewHallucinations`
- PASS: `coverageComplete`
- PASS: `stabilitySuccess`
- PASS: `memoryEvidence`
- PASS: `memoryFloor`
- PASS: `swapStable`

Decision: **STOP**.

This corpus binds every required language and product-speech class. It qualifies CPU/Vulkan parity only for the exact measured identity, not general model quality. Cache, reset, driver, and production selection remain separate bound gates.

# Whisper acceleration probe

| Candidate | Backend | Median outer ms | p95 outer ms | Runs |
| --- | --- | ---: | ---: | ---: |
| cpu | cpu | 16955.882 | 16955.882 | 1 |
| accelerated | vulkan | 18532.288 | 18532.288 | 1 |

Paired median speedup: **-9.297%**.
Paired median reduction: **-1576.406 ms**.
Decision: **STOP**.

## Gates

- PASS: `backendTruth`
- PASS: `hardwareDevice`
- PASS: `runtimeReceipt`
- PASS: `pairedCompleteness`
- FAIL: `sampleSize`
- PASS: `transcriptParity`
- FAIL: `medianSpeedup`
- FAIL: `medianReduction`
- FAIL: `p95Improved`

This probe proves backend creation, its selected physical-device receipt, paired latency, and exact transcript parity only. The receipt does not prove an ICD manifest or loaded-library digests; launch evidence owns those. It does not replace the multilingual WER/CER and silence corpus gate.

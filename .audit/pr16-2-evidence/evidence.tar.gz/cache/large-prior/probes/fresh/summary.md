# Whisper acceleration probe

| Candidate | Backend | Median outer ms | p95 outer ms | Runs |
| --- | --- | ---: | ---: | ---: |
| cpu | cpu | 16208.292 | 16208.292 | 1 |
| accelerated | vulkan | 11112.052 | 11112.052 | 1 |

Paired median speedup: **31.442%**.
Paired median reduction: **5096.24 ms**.
Decision: **STOP**.

## Gates

- PASS: `backendTruth`
- PASS: `hardwareDevice`
- PASS: `runtimeReceipt`
- PASS: `pairedCompleteness`
- FAIL: `sampleSize`
- PASS: `transcriptParity`
- PASS: `medianSpeedup`
- PASS: `medianReduction`
- PASS: `p95Improved`

This probe proves backend creation, its selected physical-device receipt, paired latency, and exact transcript parity only. The receipt does not prove an ICD manifest or loaded-library digests; launch evidence owns those. It does not replace the multilingual WER/CER and silence corpus gate.

# Whisper acceleration probe

| Candidate | Backend | Median outer ms | p95 outer ms | Runs |
| --- | --- | ---: | ---: | ---: |
| cpu | cpu | 3766.291 | 3766.291 | 1 |
| accelerated | vulkan | 1596.03 | 1596.03 | 1 |

Paired median speedup: **57.623%**.
Paired median reduction: **2170.261 ms**.
Decision: **STOP**.

## Gates

- PASS: `backendTruth`
- PASS: `hardwareDevice`
- PASS: `runtimeReceipt`
- PASS: `pairedCompleteness`
- FAIL: `sampleSize`
- PASS: `transcriptParity`
- PASS: `medianSpeedup`
- PASS: `medianReduction`
- PASS: `p95Improved`

This probe proves backend creation, its selected physical-device receipt, paired latency, and exact transcript parity only. The receipt does not prove an ICD manifest or loaded-library digests; launch evidence owns those. It does not replace the multilingual WER/CER and silence corpus gate.
